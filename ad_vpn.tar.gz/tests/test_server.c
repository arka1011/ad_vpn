#include "../server/server.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

// Test configuration
#define TEST_BIND_IP "127.0.0.1"
#define TEST_BIND_PORT 8080
#define TEST_TUN_CIDR "10.8.0.1/24"
#define TEST_MTU 1400
#define TEST_PSK "test_psk_32_bytes_long_secret_key"
#define TEST_WAN_IF "eth0"
#define TEST_VPN_SUBNET "10.8.0.0/24"

static int test_passed = 0;
static int test_failed = 0;

#define TEST_ASSERT(condition, message) do { \
    if (condition) { \
        printf("✓ %s\n", message); \
        test_passed++; \
    } else { \
        printf("✗ %s\n", message); \
        test_failed++; \
    } \
} while(0)

void test_server_init() {
    printf("\n=== Testing Server Initialization ===\n");
    
    server_ctx_t server;
    memset(&server, 0, sizeof(server));
    
    // Test with invalid parameters
    int ret = server_init(&server, NULL, TEST_MTU, TEST_BIND_IP, TEST_BIND_PORT, AUTH_PSK, TEST_PSK, TEST_WAN_IF, TEST_VPN_SUBNET);
    TEST_ASSERT(ret < 0, "server_init should fail with NULL tun_cidr");
    
    ret = server_init(&server, TEST_TUN_CIDR, TEST_MTU, NULL, TEST_BIND_PORT, AUTH_PSK, TEST_PSK, TEST_WAN_IF, TEST_VPN_SUBNET);
    TEST_ASSERT(ret < 0, "server_init should fail with NULL bind_ip");
    
    ret = server_init(&server, TEST_TUN_CIDR, TEST_MTU, TEST_BIND_IP, TEST_BIND_PORT, AUTH_PSK, NULL, TEST_WAN_IF, TEST_VPN_SUBNET);
    TEST_ASSERT(ret < 0, "server_init should fail with NULL psk_or_issuer");
    
    ret = server_init(&server, TEST_TUN_CIDR, TEST_MTU, TEST_BIND_IP, TEST_BIND_PORT, AUTH_PSK, TEST_PSK, NULL, TEST_VPN_SUBNET);
    TEST_ASSERT(ret < 0, "server_init should fail with NULL wan_if");
    
    ret = server_init(&server, TEST_TUN_CIDR, TEST_MTU, TEST_BIND_IP, TEST_BIND_PORT, AUTH_PSK, TEST_PSK, TEST_WAN_IF, NULL);
    TEST_ASSERT(ret < 0, "server_init should fail with NULL vpn_subnet");
    
    // Test with invalid CIDR
    ret = server_init(&server, "invalid_cidr", TEST_MTU, TEST_BIND_IP, TEST_BIND_PORT, AUTH_PSK, TEST_PSK, TEST_WAN_IF, TEST_VPN_SUBNET);
    TEST_ASSERT(ret < 0, "server_init should fail with invalid CIDR");
    
    // Test with invalid MTU
    ret = server_init(&server, TEST_TUN_CIDR, 0, TEST_BIND_IP, TEST_BIND_PORT, AUTH_PSK, TEST_PSK, TEST_WAN_IF, TEST_VPN_SUBNET);
    TEST_ASSERT(ret < 0, "server_init should fail with invalid MTU");
    
    printf("Server initialization tests completed: %d passed, %d failed\n", test_passed, test_failed);
}

void test_server_configuration() {
    printf("\n=== Testing Server Configuration ===\n");
    
    server_ctx_t server;
    memset(&server, 0, sizeof(server));
    
    // Test configuration storage
    strcpy(server.tun_cidr, "10.0.0.1/16");
    server.mtu = 1500;
    strcpy(server.bind_ip, "192.168.1.100");
    server.bind_port = 12345;
    server.auth_mode = AUTH_TOKEN;
    strcpy(server.psk_or_issuer, "test_token");
    strcpy(server.wan_if, "eth1");
    strcpy(server.vpn_subnet, "10.0.0.0/16");
    
    TEST_ASSERT(strcmp(server.tun_cidr, "10.0.0.1/16") == 0, "TUN CIDR should be stored correctly");
    TEST_ASSERT(server.mtu == 1500, "MTU should be stored correctly");
    TEST_ASSERT(strcmp(server.bind_ip, "192.168.1.100") == 0, "Bind IP should be stored correctly");
    TEST_ASSERT(server.bind_port == 12345, "Bind port should be stored correctly");
    TEST_ASSERT(server.auth_mode == AUTH_TOKEN, "Auth mode should be stored correctly");
    TEST_ASSERT(strcmp(server.psk_or_issuer, "test_token") == 0, "PSK/token should be stored correctly");
    TEST_ASSERT(strcmp(server.wan_if, "eth1") == 0, "WAN interface should be stored correctly");
    TEST_ASSERT(strcmp(server.vpn_subnet, "10.0.0.0/16") == 0, "VPN subnet should be stored correctly");
    
    printf("Server configuration tests completed: %d passed, %d failed\n", test_passed, test_failed);
}

void test_server_session_management() {
    printf("\n=== Testing Server Session Management ===\n");
    
    server_ctx_t server;
    memset(&server, 0, sizeof(server));
    
    // Test session state
    server.client_connected = 0;
    server.listen_fd = -1;
    server.conn_fd = -1;
    
    TEST_ASSERT(server.client_connected == 0, "Default client_connected should be 0");
    TEST_ASSERT(server.listen_fd == -1, "Default listen_fd should be -1");
    TEST_ASSERT(server.conn_fd == -1, "Default conn_fd should be -1");
    
    // Test session configuration
    server.client_connected = 1;
    strcpy(server.client_ip, "192.168.1.100");
    server.client_port = 54321;
    server.client_connect_time = time(NULL);
    
    TEST_ASSERT(server.client_connected == 1, "client_connected should be set correctly");
    TEST_ASSERT(strcmp(server.client_ip, "192.168.1.100") == 0, "client_ip should be set correctly");
    TEST_ASSERT(server.client_port == 54321, "client_port should be set correctly");
    TEST_ASSERT(server.client_connect_time > 0, "client_connect_time should be set correctly");
    
    printf("Server session management tests completed: %d passed, %d failed\n", test_passed, test_failed);
}

void test_server_statistics() {
    printf("\n=== Testing Server Statistics ===\n");
    
    server_ctx_t server;
    memset(&server, 0, sizeof(server));
    
    // Test default statistics
    TEST_ASSERT(server.bytes_received == 0, "Default bytes_received should be 0");
    TEST_ASSERT(server.bytes_sent == 0, "Default bytes_sent should be 0");
    TEST_ASSERT(server.packets_received == 0, "Default packets_received should be 0");
    TEST_ASSERT(server.packets_sent == 0, "Default packets_sent should be 0");
    
    // Test statistics updates
    server.bytes_received = 1024;
    server.bytes_sent = 2048;
    server.packets_received = 10;
    server.packets_sent = 20;
    
    TEST_ASSERT(server.bytes_received == 1024, "bytes_received should be updated correctly");
    TEST_ASSERT(server.bytes_sent == 2048, "bytes_sent should be updated correctly");
    TEST_ASSERT(server.packets_received == 10, "packets_received should be updated correctly");
    TEST_ASSERT(server.packets_sent == 20, "packets_sent should be updated correctly");
    
    printf("Server statistics tests completed: %d passed, %d failed\n", test_passed, test_failed);
}

void test_server_signal_handling() {
    printf("\n=== Testing Server Signal Handling ===\n");
    
    server_ctx_t server;
    memset(&server, 0, sizeof(server));
    
    // Test signal handler setup
    server.running = 1;
    
    // Simulate SIGINT
    handle_sigint(SIGINT);
    TEST_ASSERT(1, "Signal handler should not crash");
    
    // Simulate SIGTERM
    handle_sigterm(SIGTERM);
    TEST_ASSERT(1, "Signal handler should not crash");
    
    printf("Server signal handling tests completed: %d passed, %d failed\n", test_passed, test_failed);
}

void test_server_constants() {
    printf("\n=== Testing Server Constants ===\n");
    
    // Test default parameters
    TEST_ASSERT(DEFAULT_BACKLOG == 5, "DEFAULT_BACKLOG should be 5");
    TEST_ASSERT(DEFAULT_SELECT_TIMEOUT == 1, "DEFAULT_SELECT_TIMEOUT should be 1");
    TEST_ASSERT(MAX_CLIENTS == 1, "MAX_CLIENTS should be 1");
    
    printf("Server constants tests completed: %d passed, %d failed\n", test_passed, test_failed);
}

int main() {
    printf("Starting Server Module Tests\n");
    printf("============================\n");
    
    // Run all tests
    test_server_constants();
    test_server_configuration();
    test_server_session_management();
    test_server_statistics();
    test_server_signal_handling();
    test_server_init();
    
    // Summary
    printf("\n=== Test Summary ===\n");
    printf("Total tests: %d\n", test_passed + test_failed);
    printf("Passed: %d\n", test_passed);
    printf("Failed: %d\n", test_failed);
    
    if (test_failed == 0) {
        printf("✓ All tests passed!\n");
        return 0;
    } else {
        printf("✗ Some tests failed!\n");
        return 1;
    }
}
