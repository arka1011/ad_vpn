#include "../secure_channel/secure_channel.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <pthread.h>

static int test_passed = 0;
static int test_failed = 0;

#define TEST_ASSERT(condition, message) do { \
    if (condition) { \
        printf("✓ %s\n", message); \
        test_passed++; \
    } else { \
        printf("✗ %s\n", message); \
        test_failed++; \
    } \
} while(0)

// Test server thread function
void* test_server_thread(void* arg) {
    int server_fd = *(int*)arg;
    struct sockaddr_in client_addr;
    socklen_t client_len = sizeof(client_addr);
    
    int client_fd = accept(server_fd, (struct sockaddr*)&client_addr, &client_len);
    if (client_fd < 0) {
        return NULL;
    }
    
    // Initialize secure channel for server
    secure_chan_t sc;
    memset(&sc, 0, sizeof(sc));
    sc.sock_fd = client_fd;
    sc.auth_mode = AUTH_PSK;
    strcpy(sc.psk_hex, "test_psk_32_bytes_long_secret_key");
    
    // Perform server handshake
    int ret = sc_server_begin(&sc);
    if (ret == 0) {
        ret = sc_server_finish(&sc);
    }
    
    if (ret == 0) {
        // Send test message
        const char* msg = "Hello from server!";
        sc_send_data(&sc, (const uint8_t*)msg, strlen(msg));
        
        // Receive response
        uint8_t buf[256];
        ssize_t n = sc_recv_data(&sc, buf, sizeof(buf));
        if (n > 0) {
            buf[n] = '\0';
            printf("Server received: %s\n", (char*)buf);
        }
        
        sc_close(&sc);
    }
    
    close(client_fd);
    return NULL;
}

void test_secure_channel_handshake() {
    printf("\n=== Testing Secure Channel Handshake ===\n");
    
    // Create server socket
    int server_fd = socket(AF_INET, SOCK_STREAM, 0);
    TEST_ASSERT(server_fd >= 0, "Server socket creation should succeed");
    
    struct sockaddr_in server_addr = {0};
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(0); // Let OS choose port
    
    int opt = 1;
    setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));
    
    int ret = bind(server_fd, (struct sockaddr*)&server_addr, sizeof(server_addr));
    TEST_ASSERT(ret == 0, "Server bind should succeed");
    
    ret = listen(server_fd, 1);
    TEST_ASSERT(ret == 0, "Server listen should succeed");
    
    // Get the assigned port
    socklen_t addr_len = sizeof(server_addr);
    getsockname(server_fd, (struct sockaddr*)&server_addr, &addr_len);
    int port = ntohs(server_addr.sin_port);
    
    // Start server thread
    pthread_t server_thread;
    ret = pthread_create(&server_thread, NULL, test_server_thread, &server_fd);
    TEST_ASSERT(ret == 0, "Server thread creation should succeed");
    
    // Wait a bit for server to start
    usleep(100000);
    
    // Create client socket
    int client_fd = socket(AF_INET, SOCK_STREAM, 0);
    TEST_ASSERT(client_fd >= 0, "Client socket creation should succeed");
    
    struct sockaddr_in client_addr = {0};
    client_addr.sin_family = AF_INET;
    client_addr.sin_port = htons(port);
    inet_pton(AF_INET, "127.0.0.1", &client_addr.sin_addr);
    
    ret = connect(client_fd, (struct sockaddr*)&client_addr, sizeof(client_addr));
    TEST_ASSERT(ret == 0, "Client connect should succeed");
    
    // Initialize secure channel for client
    secure_chan_t sc;
    memset(&sc, 0, sizeof(sc));
    sc.sock_fd = client_fd;
    sc.auth_mode = AUTH_PSK;
    strcpy(sc.psk_hex, "test_psk_32_bytes_long_secret_key");
    
    // Perform client handshake
    ret = sc_client_begin(&sc);
    TEST_ASSERT(ret == 0, "Client handshake begin should succeed");
    
    ret = sc_client_finish(&sc);
    TEST_ASSERT(ret == 0, "Client handshake finish should succeed");
    
    // Receive message from server
    uint8_t buf[256];
    ssize_t n = sc_recv_data(&sc, buf, sizeof(buf));
    TEST_ASSERT(n > 0, "Client should receive data from server");
    
    if (n > 0) {
        buf[n] = '\0';
        printf("Client received: %s\n", (char*)buf);
        
        // Send response
        const char* response = "Hello from client!";
        ret = sc_send_data(&sc, (const uint8_t*)response, strlen(response));
        TEST_ASSERT(ret == 0, "Client should send data successfully");
    }
    
    // Cleanup
    sc_close(&sc);
    close(client_fd);
    close(server_fd);
    pthread_join(server_thread, NULL);
    
    printf("Secure channel handshake tests completed: %d passed, %d failed\n", test_passed, test_failed);
}

void test_secure_channel_configuration() {
    printf("\n=== Testing Secure Channel Configuration ===\n");
    
    secure_chan_t sc;
    memset(&sc, 0, sizeof(sc));
    
    // Test default values
    TEST_ASSERT(sc.sock_fd == 0, "Default sock_fd should be 0");
    TEST_ASSERT(sc.is_established == 0, "Default is_established should be 0");
    TEST_ASSERT(sc.auth_mode == 0, "Default auth_mode should be 0");
    
    // Test configuration
    sc.sock_fd = 123;
    sc.auth_mode = AUTH_PSK;
    strcpy(sc.psk_hex, "test_key");
    sc.is_established = 1;
    
    TEST_ASSERT(sc.sock_fd == 123, "sock_fd should be set correctly");
    TEST_ASSERT(sc.auth_mode == AUTH_PSK, "auth_mode should be set correctly");
    TEST_ASSERT(strcmp(sc.psk_hex, "test_key") == 0, "psk_hex should be set correctly");
    TEST_ASSERT(sc.is_established == 1, "is_established should be set correctly");
    
    printf("Secure channel configuration tests completed: %d passed, %d failed\n", test_passed, test_failed);
}

void test_secure_channel_constants() {
    printf("\n=== Testing Secure Channel Constants ===\n");
    
    // Test protocol constants
    TEST_ASSERT(SC_PROTO_VER == 1, "Protocol version should be 1");
    TEST_ASSERT(SC_MAX_RECORD_PLAINTEXT == 1500, "Max record plaintext should be 1500");
    TEST_ASSERT(SC_TAG_LEN == 16, "Tag length should be 16");
    TEST_ASSERT(SC_NONCE_LEN == 12, "Nonce length should be 12");
    TEST_ASSERT(SC_X25519_KEY_LEN == 32, "X25519 key length should be 32");
    TEST_ASSERT(SC_HELLO_NONCE_LEN == 16, "Hello nonce length should be 16");
    TEST_ASSERT(SC_SEQ_LEN == 8, "Sequence length should be 8");
    TEST_ASSERT(SC_TYPE_DATA == 0x17, "Data type should be 0x17");
    TEST_ASSERT(SC_TYPE_CONTROL == 0x15, "Control type should be 0x15");
    
    // Test error codes
    TEST_ASSERT(SC_OK == 0, "SC_OK should be 0");
    TEST_ASSERT(SC_ERR_IO == -1, "SC_ERR_IO should be -1");
    TEST_ASSERT(SC_ERR_PROTO == -2, "SC_ERR_PROTO should be -2");
    TEST_ASSERT(SC_ERR_AUTH == -3, "SC_ERR_AUTH should be -3");
    TEST_ASSERT(SC_ERR_CRYPTO == -4, "SC_ERR_CRYPTO should be -4");
    TEST_ASSERT(SC_ERR_REPLAY == -5, "SC_ERR_REPLAY should be -5");
    TEST_ASSERT(SC_ERR_STATE == -6, "SC_ERR_STATE should be -6");
    TEST_ASSERT(SC_ERR_PARAM == -7, "SC_ERR_PARAM should be -7");
    
    // Test auth modes
    TEST_ASSERT(AUTH_PSK == 1, "AUTH_PSK should be 1");
    TEST_ASSERT(AUTH_TOKEN == 2, "AUTH_TOKEN should be 2");
    TEST_ASSERT(AUTH_MUTUALCERT == 3, "AUTH_MUTUALCERT should be 3");
    
    // Test control message types
    TEST_ASSERT(SC_CTL_CLIENT_HELLO == 1, "SC_CTL_CLIENT_HELLO should be 1");
    TEST_ASSERT(SC_CTL_SERVER_HELLO == 2, "SC_CTL_SERVER_HELLO should be 2");
    TEST_ASSERT(SC_CTL_FINISH == 3, "SC_CTL_FINISH should be 3");
    TEST_ASSERT(SC_CTL_FINISH_ACK == 4, "SC_CTL_FINISH_ACK should be 4");
    
    // Test cipher types
    TEST_ASSERT(SC_CIPHER_CHACHA20_POLY1305 == 1, "SC_CIPHER_CHACHA20_POLY1305 should be 1");
    TEST_ASSERT(SC_CIPHER_AES_256_GCM == 2, "SC_CIPHER_AES_256_GCM should be 2");
    
    printf("Secure channel constants tests completed: %d passed, %d failed\n", test_passed, test_failed);
}

void test_secure_channel_structures() {
    printf("\n=== Testing Secure Channel Structures ===\n");
    
    // Test crypto_ctx_t structure
    crypto_ctx_t crypto_ctx;
    memset(&crypto_ctx, 0, sizeof(crypto_ctx));
    
    TEST_ASSERT(sizeof(crypto_ctx.key) == 32, "crypto_ctx.key should be 32 bytes");
    TEST_ASSERT(sizeof(crypto_ctx.iv_base) == SC_NONCE_LEN, "crypto_ctx.iv_base should be SC_NONCE_LEN bytes");
    TEST_ASSERT(crypto_ctx.send_seq == 0, "Default send_seq should be 0");
    TEST_ASSERT(crypto_ctx.recv_highest == 0, "Default recv_highest should be 0");
    TEST_ASSERT(crypto_ctx.recv_window == 0, "Default recv_window should be 0");
    
    // Test secure_chan_t structure
    secure_chan_t sc;
    memset(&sc, 0, sizeof(sc));
    
    TEST_ASSERT(sizeof(sc.c_pub) == SC_X25519_KEY_LEN, "sc.c_pub should be SC_X25519_KEY_LEN bytes");
    TEST_ASSERT(sizeof(sc.c_priv) == SC_X25519_KEY_LEN, "sc.c_priv should be SC_X25519_KEY_LEN bytes");
    TEST_ASSERT(sizeof(sc.s_pub) == SC_X25519_KEY_LEN, "sc.s_pub should be SC_X25519_KEY_LEN bytes");
    TEST_ASSERT(sizeof(sc.shared) == SC_X25519_KEY_LEN, "sc.shared should be SC_X25519_KEY_LEN bytes");
    TEST_ASSERT(sizeof(sc.client_nonce) == SC_HELLO_NONCE_LEN, "sc.client_nonce should be SC_HELLO_NONCE_LEN bytes");
    TEST_ASSERT(sizeof(sc.server_nonce) == SC_HELLO_NONCE_LEN, "sc.server_nonce should be SC_HELLO_NONCE_LEN bytes");
    TEST_ASSERT(sizeof(sc.psk_hex) == 65, "sc.psk_hex should be 65 bytes");
    TEST_ASSERT(sizeof(sc.token) == 128, "sc.token should be 128 bytes");
    
    printf("Secure channel structures tests completed: %d passed, %d failed\n", test_passed, test_failed);
}

int main() {
    printf("Starting Secure Channel Module Tests\n");
    printf("====================================\n");
    
    // Run all tests
    test_secure_channel_constants();
    test_secure_channel_structures();
    test_secure_channel_configuration();
    test_secure_channel_handshake();
    
    // Summary
    printf("\n=== Test Summary ===\n");
    printf("Total tests: %d\n", test_passed + test_failed);
    printf("Passed: %d\n", test_passed);
    printf("Failed: %d\n", test_failed);
    
    if (test_failed == 0) {
        printf("✓ All tests passed!\n");
        return 0;
    } else {
        printf("✗ Some tests failed!\n");
        return 1;
    }
}
