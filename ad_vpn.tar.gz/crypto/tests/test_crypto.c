#include "crypto.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

static int test_passed = 0;
static int test_failed = 0;

#define TEST_ASSERT(condition, message) do { \
    if (condition) { \
        printf("✓ %s\n", message); \
        test_passed++; \
    } else { \
        printf("✗ %s\n", message); \
        test_failed++; \
    } \
} while(0)

void test_crypto_random() {
    printf("\n=== Testing Crypto Random ===\n");
    
    uint8_t buf1[32], buf2[32];
    
    // Test random generation
    int ret = crypto_random(buf1, sizeof(buf1));
    TEST_ASSERT(ret == 0, "crypto_random should succeed");
    
    ret = crypto_random(buf2, sizeof(buf2));
    TEST_ASSERT(ret == 0, "crypto_random should succeed");
    
    // Test that we get different random values
    int different = 0;
    for (size_t i = 0; i < sizeof(buf1); i++) {
        if (buf1[i] != buf2[i]) {
            different = 1;
            break;
        }
    }
    TEST_ASSERT(different, "Random values should be different");
    
    printf("Crypto random tests completed: %d passed, %d failed\n", test_passed, test_failed);
}

void test_x25519_keypair() {
    printf("\n=== Testing X25519 Keypair Generation ===\n");
    
    uint8_t pub1[32], priv1[32];
    uint8_t pub2[32], priv2[32];
    
    // Generate keypair 1
    int ret = crypto_x25519_keypair(pub1, priv1);
    TEST_ASSERT(ret == 0, "X25519 keypair generation should succeed");
    
    // Generate keypair 2
    ret = crypto_x25519_keypair(pub2, priv2);
    TEST_ASSERT(ret == 0, "X25519 keypair generation should succeed");
    
    // Test that we get different keypairs
    int different_pub = 0, different_priv = 0;
    for (int i = 0; i < 32; i++) {
        if (pub1[i] != pub2[i]) different_pub = 1;
        if (priv1[i] != priv2[i]) different_priv = 1;
    }
    TEST_ASSERT(different_pub, "Public keys should be different");
    TEST_ASSERT(different_priv, "Private keys should be different");
    
    printf("X25519 keypair tests completed: %d passed, %d failed\n", test_passed, test_failed);
}

void test_x25519_shared() {
    printf("\n=== Testing X25519 Shared Secret ===\n");
    
    uint8_t alice_pub[32], alice_priv[32];
    uint8_t bob_pub[32], bob_priv[32];
    uint8_t alice_shared[32], bob_shared[32];
    
    // Generate keypairs
    int ret = crypto_x25519_keypair(alice_pub, alice_priv);
    TEST_ASSERT(ret == 0, "Alice keypair generation should succeed");
    
    ret = crypto_x25519_keypair(bob_pub, bob_priv);
    TEST_ASSERT(ret == 0, "Bob keypair generation should succeed");
    
    // Compute shared secrets
    ret = crypto_x25519_shared(alice_shared, alice_priv, bob_pub);
    TEST_ASSERT(ret == 0, "Alice shared secret computation should succeed");
    
    ret = crypto_x25519_shared(bob_shared, bob_priv, alice_pub);
    TEST_ASSERT(ret == 0, "Bob shared secret computation should succeed");
    
    // Test that both parties get the same shared secret
    int same = 1;
    for (int i = 0; i < 32; i++) {
        if (alice_shared[i] != bob_shared[i]) {
            same = 0;
            break;
        }
    }
    TEST_ASSERT(same, "Both parties should compute the same shared secret");
    
    printf("X25519 shared secret tests completed: %d passed, %d failed\n", test_passed, test_failed);
}

void test_hkdf_expand_label() {
    printf("\n=== Testing HKDF Expand Label ===\n");
    
    uint8_t secret[32] = {0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08,
                          0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f, 0x10,
                          0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18,
                          0x19, 0x1a, 0x1b, 0x1c, 0x1d, 0x1e, 0x1f, 0x20};
    
    uint8_t info[16] = {0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08,
                        0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f, 0x10};
    
    uint8_t out1[32], out2[32];
    
    // Test HKDF expand with different labels
    int ret = crypto_hkdf_expand_label(secret, sizeof(secret), "client", info, sizeof(info), out1, sizeof(out1));
    TEST_ASSERT(ret == 0, "HKDF expand with 'client' label should succeed");
    
    ret = crypto_hkdf_expand_label(secret, sizeof(secret), "server", info, sizeof(info), out2, sizeof(out2));
    TEST_ASSERT(ret == 0, "HKDF expand with 'server' label should succeed");
    
    // Test that different labels produce different outputs
    int different = 0;
    for (int i = 0; i < 32; i++) {
        if (out1[i] != out2[i]) {
            different = 1;
            break;
        }
    }
    TEST_ASSERT(different, "Different labels should produce different outputs");
    
    printf("HKDF expand label tests completed: %d passed, %d failed\n", test_passed, test_failed);
}

void test_aead_encrypt_decrypt() {
    printf("\n=== Testing AEAD Encrypt/Decrypt ===\n");
    
    crypto_ctx_t ctx;
    memset(&ctx, 0, sizeof(ctx));
    
    // Generate random key and salt
    int ret = crypto_random(ctx.key, sizeof(ctx.key));
    TEST_ASSERT(ret == 0, "Random key generation should succeed");
    
    ret = crypto_random(ctx.salt, sizeof(ctx.salt));
    TEST_ASSERT(ret == 0, "Random salt generation should succeed");
    
    // Test data
    const char *plaintext = "Hello, World! This is a test message.";
    size_t pt_len = strlen(plaintext);
    const char *aad = "Additional authenticated data";
    size_t aad_len = strlen(aad);
    
    uint8_t ciphertext[pt_len + 16]; // plaintext + tag
    size_t ct_len = 0;
    
    // Encrypt
    ret = crypto_aead_encrypt(&ctx, 1, (const uint8_t*)plaintext, pt_len, 
                             (const uint8_t*)aad, aad_len, ciphertext, &ct_len);
    TEST_ASSERT(ret == 0, "AEAD encryption should succeed");
    TEST_ASSERT(ct_len == pt_len + 16, "Ciphertext length should be plaintext + tag");
    
    // Decrypt
    uint8_t decrypted[pt_len];
    size_t decrypted_len = 0;
    
    ret = crypto_aead_decrypt(&ctx, 1, ciphertext, ct_len, 
                             (const uint8_t*)aad, aad_len, decrypted, &decrypted_len);
    TEST_ASSERT(ret == 0, "AEAD decryption should succeed");
    TEST_ASSERT(decrypted_len == pt_len, "Decrypted length should match original");
    TEST_ASSERT(memcmp(plaintext, decrypted, pt_len) == 0, "Decrypted data should match original");
    
    // Test with wrong sequence number (should fail)
    ret = crypto_aead_decrypt(&ctx, 2, ciphertext, ct_len, 
                             (const uint8_t*)aad, aad_len, decrypted, &decrypted_len);
    TEST_ASSERT(ret < 0, "AEAD decryption with wrong sequence should fail");
    
    printf("AEAD encrypt/decrypt tests completed: %d passed, %d failed\n", test_passed, test_failed);
}

void test_aead_replay_protection() {
    printf("\n=== Testing AEAD Replay Protection ===\n");
    
    crypto_ctx_t ctx;
    memset(&ctx, 0, sizeof(ctx));
    
    // Generate random key and salt
    crypto_random(ctx.key, sizeof(ctx.key));
    crypto_random(ctx.salt, sizeof(ctx.salt));
    
    const char *plaintext = "Test message";
    size_t pt_len = strlen(plaintext);
    uint8_t ciphertext[pt_len + 16];
    size_t ct_len = 0;
    
    // Encrypt with sequence 1
    int ret = crypto_aead_encrypt(&ctx, 1, (const uint8_t*)plaintext, pt_len, 
                                 NULL, 0, ciphertext, &ct_len);
    TEST_ASSERT(ret == 0, "First encryption should succeed");
    
    // Decrypt with sequence 1 (should succeed)
    uint8_t decrypted[pt_len];
    size_t decrypted_len = 0;
    ret = crypto_aead_decrypt(&ctx, 1, ciphertext, ct_len, 
                             NULL, 0, decrypted, &decrypted_len);
    TEST_ASSERT(ret == 0, "First decryption should succeed");
    
    // Try to decrypt again with sequence 1 (should fail - replay)
    ret = crypto_aead_decrypt(&ctx, 1, ciphertext, ct_len, 
                             NULL, 0, decrypted, &decrypted_len);
    TEST_ASSERT(ret < 0, "Replay decryption should fail");
    
    // Decrypt with sequence 2 (should fail - wrong sequence)
    ret = crypto_aead_decrypt(&ctx, 2, ciphertext, ct_len, 
                             NULL, 0, decrypted, &decrypted_len);
    TEST_ASSERT(ret < 0, "Wrong sequence decryption should fail");
    
    printf("AEAD replay protection tests completed: %d passed, %d failed\n", test_passed, test_failed);
}

int main() {
    printf("Starting Crypto Module Tests\n");
    printf("============================\n");
    
    // Run all tests
    test_crypto_random();
    test_x25519_keypair();
    test_x25519_shared();
    test_hkdf_expand_label();
    test_aead_encrypt_decrypt();
    test_aead_replay_protection();
    
    // Summary
    printf("\n=== Test Summary ===\n");
    printf("Total tests: %d\n", test_passed + test_failed);
    printf("Passed: %d\n", test_passed);
    printf("Failed: %d\n", test_failed);
    
    if (test_failed == 0) {
        printf("✓ All tests passed!\n");
        return 0;
    } else {
        printf("✗ Some tests failed!\n");
        return 1;
    }
}
