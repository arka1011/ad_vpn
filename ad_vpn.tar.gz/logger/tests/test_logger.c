#include <stdio.h>
#include <assert.h>
#include "../src/logger.h"

void test_logger_basic() {
    assert(logger_init("test.log", LOG_LEVEL_DEBUG) == 0);
    LOG_INFO("Logger info test");
    LOG_DEBUG("Logger debug test");
    LOG_WARN("Logger warn test");
    LOG_ERROR("Logger error test");
    logger_set_level(LOG_LEVEL_TRACE);
    LOG_TRACE("Logger trace test");
    logger_cleanup();
    printf("Logger basic test passed\n");
}

int main() {
    test_logger_basic();
    printf("Logger tests completed.\n");
    return 0;
}
