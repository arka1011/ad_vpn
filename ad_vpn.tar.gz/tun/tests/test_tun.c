#include <stdio.h>
#include <string.h>
#include <assert.h>
#include "../tun/tun_utils.h"

void test_cidr_to_addr_mask() {
    char ip[32], mask[32];
    cidr_to_addr_mask("10.0.0.1/24", ip, sizeof(ip), mask, sizeof(mask));
    assert(strcmp(ip, "10.0.0.1") == 0);
    assert(strcmp(mask, "255.255.255.0") == 0);

    cidr_to_addr_mask("192.168.1.10/16", ip, sizeof(ip), mask, sizeof(mask));
    assert(strcmp(ip, "192.168.1.10") == 0);
    assert(strcmp(mask, "255.255.0.0") == 0);

    cidr_to_addr_mask("1.2.3.4", ip, sizeof(ip), mask, sizeof(mask));
    assert(strcmp(ip, "1.2.3.4") == 0);
    assert(strcmp(mask, "255.255.255.255") == 0);

    printf("cidr_to_addr_mask test passed\n");
}

void test_tun_create_and_configure() {
#ifdef __linux__
    char ifname[IFNAMSIZ] = "tun_test0";
    int fd = tun_create(ifname, sizeof(ifname));
    assert(fd >= 0);
    assert(strlen(ifname) > 0);

    assert(if_set_addr_netmask(ifname, "10.10.10.1", "255.255.255.0") == 0);
    assert(if_set_mtu(ifname, 1400) == 0);
    assert(if_set_flags(ifname, IFF_UP | IFF_RUNNING, 1) == 0);

    close(fd);
    printf("TUN create/configure test passed (run as root on Linux)\n");
#else
    printf("TUN tests skipped (not on Linux)\n");
#endif
}

int main() {
    test_cidr_to_addr_mask();
    test_tun_create_and_configure();
    printf("TUN tests completed.\n");
    return 0;
}
