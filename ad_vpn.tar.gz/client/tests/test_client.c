#include "client.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>

// Test configuration
#define TEST_SERVER_IP "127.0.0.1"
#define TEST_SERVER_PORT 8080
#define TEST_TUN_CIDR "10.8.0.2/24"
#define TEST_MTU 1400
#define TEST_PSK "test_psk_32_bytes_long_secret_key"

static int test_passed = 0;
static int test_failed = 0;

#define TEST_ASSERT(condition, message) do { \
    if (condition) { \
        printf("✓ %s\n", message); \
        test_passed++; \
    } else { \
        printf("✗ %s\n", message); \
        test_failed++; \
    } \
} while(0)

void test_client_init() {
    printf("\n=== Testing Client Initialization ===\n");
    
    client_ctx_t client;
    memset(&client, 0, sizeof(client));
    
    // Test with invalid parameters
    int ret = client_init(&client, NULL, TEST_MTU, TEST_SERVER_IP, TEST_SERVER_PORT, AUTH_PSK, TEST_PSK, 0);
    TEST_ASSERT(ret < 0, "client_init should fail with NULL tun_cidr");
    
    ret = client_init(&client, TEST_TUN_CIDR, TEST_MTU, NULL, TEST_SERVER_PORT, AUTH_PSK, TEST_PSK, 0);
    TEST_ASSERT(ret < 0, "client_init should fail with NULL server_ip");
    
    ret = client_init(&client, TEST_TUN_CIDR, TEST_MTU, TEST_SERVER_IP, TEST_SERVER_PORT, AUTH_PSK, NULL, 0);
    TEST_ASSERT(ret < 0, "client_init should fail with NULL secret");
    
    // Test with invalid CIDR
    ret = client_init(&client, "invalid_cidr", TEST_MTU, TEST_SERVER_IP, TEST_SERVER_PORT, AUTH_PSK, TEST_PSK, 0);
    TEST_ASSERT(ret < 0, "client_init should fail with invalid CIDR");
    
    // Test with invalid MTU
    ret = client_init(&client, TEST_TUN_CIDR, 0, TEST_SERVER_IP, TEST_SERVER_PORT, AUTH_PSK, TEST_PSK, 0);
    TEST_ASSERT(ret < 0, "client_init should fail with invalid MTU");
    
    printf("Initialization tests completed: %d passed, %d failed\n", test_passed, test_failed);
}

void test_client_connect() {
    printf("\n=== Testing Client Connection ===\n");
    
    client_ctx_t client;
    memset(&client, 0, sizeof(client));
    
    // Initialize client (this will fail to connect since no server is running)
    int ret = client_init(&client, TEST_TUN_CIDR, TEST_MTU, TEST_SERVER_IP, TEST_SERVER_PORT, AUTH_PSK, TEST_PSK, 0);
    
    if (ret == 0) {
        TEST_ASSERT(client.sock_fd >= 0, "Socket should be created");
        TEST_ASSERT(client.connected == 0, "Should not be connected without server");
        
        // Test connection attempt
        ret = client_connect(&client);
        TEST_ASSERT(ret < 0, "Connection should fail without running server");
        
        client_stop(&client);
    } else {
        printf("Skipping connection tests (TUN creation requires root privileges)\n");
    }
    
    printf("Connection tests completed: %d passed, %d failed\n", test_passed, test_failed);
}

void test_client_routing() {
    printf("\n=== Testing Client Routing ===\n");
    
    client_ctx_t client;
    memset(&client, 0, sizeof(client));
    
    // Test routing setup without TUN (should fail gracefully)
    strcpy(client.tun_cidr, TEST_TUN_CIDR);
    strcpy(client.tun.ifname, "tun0");
    client.set_default_route = 1;
    
    int ret = client_setup_routing(&client);
    TEST_ASSERT(ret < 0, "Routing setup should fail without valid TUN interface");
    
    // Test routing restoration
    ret = client_restore_routing(&client);
    TEST_ASSERT(ret == 0, "Routing restoration should succeed");
    
    printf("Routing tests completed: %d passed, %d failed\n", test_passed, test_failed);
}

void test_client_reconnection() {
    printf("\n=== Testing Client Reconnection Logic ===\n");
    
    client_ctx_t client;
    memset(&client, 0, sizeof(client));
    
    // Test reconnection parameters
    client.max_reconnect_attempts = 3;
    client.reconnect_delay_sec = 1;
    client.current_reconnect_attempt = 0;
    client.last_reconnect_time = 0;
    client.connected = 0;
    client.running = 1;
    
    TEST_ASSERT(client.max_reconnect_attempts == 3, "Reconnection attempts should be set");
    TEST_ASSERT(client.reconnect_delay_sec == 1, "Reconnection delay should be set");
    
    // Test disconnect when not connected
    int ret = client_disconnect(&client);
    TEST_ASSERT(ret == 0, "Disconnect should succeed when not connected");
    
    printf("Reconnection tests completed: %d passed, %d failed\n", test_passed, test_failed);
}

void test_client_signal_handling() {
    printf("\n=== Testing Client Signal Handling ===\n");
    
    client_ctx_t client;
    memset(&client, 0, sizeof(client));
    
    // Test signal handler setup
    client.running = 1;
    
    // Simulate SIGINT
    handle_sigint(SIGINT);
    TEST_ASSERT(1, "Signal handler should not crash");
    
    // Simulate SIGTERM
    handle_sigterm(SIGTERM);
    TEST_ASSERT(1, "Signal handler should not crash");
    
    printf("Signal handling tests completed: %d passed, %d failed\n", test_passed, test_failed);
}

void test_cidr_parsing() {
    printf("\n=== Testing CIDR Parsing ===\n");
    
    char ip_str[32], mask_str[32];
    
    // Test valid CIDR
    int ret = cidr_to_addr_mask("10.8.0.1/24", ip_str, sizeof(ip_str), mask_str, sizeof(mask_str));
    TEST_ASSERT(ret == 0, "Valid CIDR should parse successfully");
    TEST_ASSERT(strcmp(ip_str, "10.8.0.1") == 0, "IP should be extracted correctly");
    TEST_ASSERT(strcmp(mask_str, "255.255.255.0") == 0, "Netmask should be extracted correctly");
    
    // Test CIDR without mask
    ret = cidr_to_addr_mask("192.168.1.100", ip_str, sizeof(ip_str), mask_str, sizeof(mask_str));
    TEST_ASSERT(ret == 0, "IP without mask should parse successfully");
    TEST_ASSERT(strcmp(ip_str, "192.168.1.100") == 0, "IP should be extracted correctly");
    TEST_ASSERT(strcmp(mask_str, "255.255.255.255") == 0, "Default mask should be 255.255.255.255");
    
    printf("CIDR parsing tests completed: %d passed, %d failed\n", test_passed, test_failed);
}

void test_client_configuration() {
    printf("\n=== Testing Client Configuration ===\n");
    
    client_ctx_t client;
    memset(&client, 0, sizeof(client));
    
    // Test configuration storage
    strcpy(client.server_ip, "192.168.1.100");
    client.server_port = 12345;
    client.auth_mode = AUTH_TOKEN;
    strcpy(client.secret_or_token, "test_token");
    strcpy(client.tun_cidr, "10.0.0.1/16");
    client.mtu = 1500;
    client.set_default_route = 1;
    
    TEST_ASSERT(strcmp(client.server_ip, "192.168.1.100") == 0, "Server IP should be stored correctly");
    TEST_ASSERT(client.server_port == 12345, "Server port should be stored correctly");
    TEST_ASSERT(client.auth_mode == AUTH_TOKEN, "Auth mode should be stored correctly");
    TEST_ASSERT(strcmp(client.secret_or_token, "test_token") == 0, "Token should be stored correctly");
    TEST_ASSERT(strcmp(client.tun_cidr, "10.0.0.1/16") == 0, "TUN CIDR should be stored correctly");
    TEST_ASSERT(client.mtu == 1500, "MTU should be stored correctly");
    TEST_ASSERT(client.set_default_route == 1, "Default route flag should be stored correctly");
    
    printf("Configuration tests completed: %d passed, %d failed\n", test_passed, test_failed);
}

int main() {
    printf("Starting Client Module Tests\n");
    printf("============================\n");
    
    // Run all tests
    test_client_configuration();
    test_cidr_parsing();
    test_client_init();
    test_client_connect();
    test_client_routing();
    test_client_reconnection();
    test_client_signal_handling();
    
    // Summary
    printf("\n=== Test Summary ===\n");
    printf("Total tests: %d\n", test_passed + test_failed);
    printf("Passed: %d\n", test_passed);
    printf("Failed: %d\n", test_failed);
    
    if (test_failed == 0) {
        printf("✓ All tests passed!\n");
        return 0;
    } else {
        printf("✗ Some tests failed!\n");
        return 1;
    }
}
